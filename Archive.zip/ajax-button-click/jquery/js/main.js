$(document).ready(function () {

    'use strict';

    $('button').click(function () {
        $.getJSON("http://echo.jsontest.com/userId/108/userName/Akademia108/userURL/akademia108.pl", function (data) {
            
            $( "button" ).after( "<p></p>" );
            
            let pText = data.userId + ' ' + data.userName + ' ' + data.userURL;
            
            $( "p" ).text(pText);
            
        });
        
    });


});