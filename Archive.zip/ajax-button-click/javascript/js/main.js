'use strict';

document.getElementById( 'btn' ).onclick = function() {
    pobierzDane("GET", "http://echo.jsontest.com/userId/108/userName/Akademia108/userURL/akademia108.pl");
};



function pobierzDane( method, url ) {
    
    let httpReq = new XMLHttpRequest();
    
    httpReq.open(method, url);
    
    httpReq.onreadystatechange = function () {
        
        if ( httpReq.readyState == 4 ) {
            
            if ( httpReq.status == 200 ) {
                
                var returnData = httpReq.responseText;
                
                var tagP = document.createElement( "p" );
                
                var textP = document.createTextNode(returnData);
                
                document.body.insertBefore(tagP, document.getElementsByTagName('script')[0]);
                
                tagP.appendChild( textP ); 
                
                httpReq = null;
            }
        }
    }
    
    httpReq.send();
}

