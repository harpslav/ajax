'use strict';

// zdefiniowanie funkcji pobierzDane
function pobierzDane(event) {
    
    // wywołaj funkcję 'ajax'
    console.log('dziala');
    ajax( "GET", "http://echo.jsontest.com/userId/108/userName/Akademia108/userURL/akademia108.pl");
    
}


// zdefiniuj zmienną dla elementu 'button'
let btn = document.getElementById('btn');

// jeden sposob pobierania zdarzenia
// btn.onclick = pobierzDane;


// drugi sposob pobierania zdarzenia
// W momencie gdy element 'button' (zdefiniowany w zmiennej 'btn') jest kliknięty, wywołaj funkcję 'pobierzDane'
btn.addEventListener('click', pobierzDane);


// zdefiniowanie funkcji 'ajax'
function ajax(method, url) {

    let httpReq = new XMLHttpRequest();

    httpReq.open(method, url);

    httpReq.onreadystatechange = function () {

        if (httpReq.readyState == 4) {

            if (httpReq.status == 200) {

                var returnData = httpReq.responseText;
                
                var returnJSONData = JSON.parse(returnData);
                
                let par = document.createElement('p');
                
                let txtNode = document.createTextNode(returnJSONData.userId + ' ' + returnJSONData.userName + ' ' + returnJSONData.userURL);
                
                par.appendChild( txtNode );
                
                // inny sposob dodania tekstu do paragrafu
                // par.innerText = returnJSONData.userId + ' ' + returnJSONData.userName + ' ' + returnJSONData.userURL;
                
                document.body.insertBefore(par, document.getElementsByTagName('script')[0]);
                
                // rozne zapisy do wstawienia paragrafu do 'body'. Aczkolwiek 'append' wstawi nowy paragraf za <script>
                // 1. document.getElementsByTagName("body")[0].appendChild(par);
                // 2. document.body.appendChild(par);

                console.log(returnJSONData);

                httpReq = null;
            }
        }
    }

    httpReq.send();
}