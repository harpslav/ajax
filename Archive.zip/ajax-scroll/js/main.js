'use strict';

window.addEventListener('scroll', function () {

    let d = document.documentElement;
    let offset = d.scrollTop + window.innerHeight;
    let height = d.offsetHeight;

    if (offset === height) {
        ajax('GET', 'https://jsonplaceholder.typicode.com/users');
    }
});




// zdefiniowanie funkcji 'ajax'
function ajax(method, url) {

    let httpReq = new XMLHttpRequest();

    httpReq.open(method, url);

    httpReq.onreadystatechange = function () {

        if (httpReq.readyState == 4) {

            if (httpReq.status == 200) {

                let returnData = httpReq.responseText;

                let returnJSONData = JSON.parse(returnData);

                for (let i = 0; i < returnJSONData.length; i++) {

                    let par = document.createElement('p');

                    par.innerHTML = 'User ID: ' + returnJSONData[i].id + '<br/>User Name: ' + returnJSONData[i].name + '<br/>User URL: ' + returnJSONData[i].website + '<br/>----------';
                    
                    document.body.insertBefore(par, document.getElementsByTagName('script')[0]);
                }

                httpReq = null;
            }
        }
    }

    httpReq.send();
}